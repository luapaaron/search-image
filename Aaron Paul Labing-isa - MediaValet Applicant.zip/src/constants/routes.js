export const ROUTE_HOME = '@route/HOME';
