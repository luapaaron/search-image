const config = {
    SERVER_BASE_URL: 'https://images-api.nasa.gov/'
};

export default config;