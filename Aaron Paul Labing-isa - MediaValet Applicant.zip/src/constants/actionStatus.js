export const PENDING = '_PENDING';
export const SUCCESS = '_SUCCESS';
export const ERROR = '_ERROR';
export const CANCELLED = '_CANCELLED';