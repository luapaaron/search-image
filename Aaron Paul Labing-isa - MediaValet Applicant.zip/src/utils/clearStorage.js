const clearStorage = () => {

}

export default clearStorage;