
const apiErrorHandler = (error, dispatch) => {
    console.warn('Something went wrong. Please try again later.', error);
}

export default apiErrorHandler;