
import config from './config';
import home from './home';

const reducers = {
    config,
    home
};

export default reducers;
