
import config from './config'

export const SET_THEME = '[CONFIG: theme] SET_THEME';

export { actionsetTheme } from './configActions';

export default config;