import { css } from '@emotion/react';

export default css`
    display: inline-flex;
    justify-content: center;
    align-items: center;
    padding: 0;
    cursor: pointer;
`;