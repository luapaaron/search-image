
import facepaint from 'facepaint';

const mq = facepaint(['@media(min-width: 601px) ', '@media(min-width: 920px) ', '@media(min-width: 1024px)']);

export default mq;
